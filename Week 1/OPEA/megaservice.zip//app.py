##cutting this down to just run LLM< maybe come back adn try both with Docker later

import os
from comps import MicroService, ServiceOrchestrator, ServiceType, ServiceRoleType
from comps.cores.proto.api_protocol import ChatCompletionRequest, ChatCompletionResponse, ChatCompletionResponseChoice
import time

EMBEDDING_SERVICE_HOST_IP = os.getenv("EMBEDDING_SERVICE_HOST_IP", "0.0.0.0")
EMBEDDING_SERVICE_PORT = os.getenv("EMBEDDING_SERVICE_PORT", 6000)
LLM_SERVICE_HOST_IP = os.getenv("LLM_SERVICE_HOST_IP", "0.0.0.0")
LLM_SERVICE_PORT = os.getenv("LLM_SERVICE_PORT", 9000)

# Define the host and port for your MEGA SERVICE (optional, but good for consistency)
MEGA_SERVICE_HOST_IP = os.getenv("MEGA_SERVICE_HOST_IP", "0.0.0.0")
MEGA_SERVICE_PORT = os.getenv("MEGA_SERVICE_PORT", 7000)


class ExampleService:
    def __init__(self, host="0.0.0.0", port=8000):
        print('ello')
        self.host = host
        self.port = port
        self.megaservice = ServiceOrchestrator()
        self.endpoint = "/v1/chat/completions" # This defines the endpoint for your megaservice

    def add_remote_service(self):
        print(f"Configuring Embedding Service: {EMBEDDING_SERVICE_HOST_IP}:{EMBEDDING_SERVICE_PORT}")
        embedding = MicroService(
            name="embedding",
            host=EMBEDDING_SERVICE_HOST_IP,
            port=EMBEDDING_SERVICE_PORT,
            endpoint="/v1/embeddings",
            use_remote_service=True,
            service_type=ServiceType.EMBEDDING,
        )
        print(f"Configuring LLM Service: {LLM_SERVICE_HOST_IP}:{LLM_SERVICE_PORT}")
        llm = MicroService(
            name="llm",
            host=LLM_SERVICE_HOST_IP,
            port=LLM_SERVICE_PORT,
            endpoint="/v1/chat/completions",
            use_remote_service=True,
            service_type=ServiceType.LLM,
        )
        self.megaservice.add(embedding).add(llm)
        self.megaservice.flow_to(embedding, llm)
        print("Megaservice flow configured: Embedding -> LLM")


    # This method handles incoming requests to your megaservice's endpoint
    async def handle_request(self, request: ChatCompletionRequest):
        print(f"Megaservice received request in handle_request: {request.messages}")

        # Extract relevant input for the orchestration flow.
        # For a chat completion, we typically use the last user message as the primary input.
        input_text = ""
        for message in request.messages:
            if message.role == "user":
                input_text = message.content
        
        # Prepare the input dictionary that your OPEA flow expects.
        # "text" is a common key for text-based inputs.
        flow_input = {"text": input_text}

        try:
            # Schedule the request through the orchestration
            # Execute the defined flow (embedding service then LLM service).
            # 'flow_result' will contain the output from the final service in the chain (your LLM).
            flow_result = await self.megaservice.run_flow(flow_input, flow_id=None, trace_id=None)

            print(f"Megaservice flow executed. Raw result from LLM service: {flow_result}")

            # Parse the 'flow_result' to extract the actual LLM's generated content.
            # The exact structure of 'flow_result' depends on your LLM microservice's output.
            llm_response_content = "Failed to get content from LLM."
            if flow_result and isinstance(flow_result, dict):
                # This checks for common OpenAI-like chat completion response structure
                if 'choices' in flow_result and len(flow_result['choices']) > 0:
                    first_choice = flow_result['choices'][0]
                    if 'message' in first_choice and 'content' in first_choice['message']:
                        llm_response_content = first_choice['message']['content']
                # This checks for simpler direct text generation responses
                elif 'response' in flow_result and isinstance(flow_result['response'], str):
                    llm_response_content = flow_result['response']
                elif 'text' in flow_result and isinstance(flow_result['text'], str): 
                    llm_response_content = flow_result['text']


            # Create response and have it return
            # Construct the ChatCompletionResponse object, conforming to the OpenAI API standard.
            choice = ChatCompletionResponseChoice(
                index=0,
                message={"role": "assistant", "content": llm_response_content},
                finish_reason="stop" # Assuming the generation completed successfully
            )

            return ChatCompletionResponse(
                id="chatcmpl-" + str(int(time.time())), # Unique ID for this specific response
                choices=[choice],
                created=int(time.time()), # Timestamp of response creation
                model=request.model if request.model else "default-megaservice-model", # Use the model name from the request, or a default
                object="chat.completion" # Standard object type for chat completions
            )

        except Exception as e:
            print(f"Error during megaservice flow execution: {e}")
            # Create response and have it return (for error case)
            # If an error occurs during orchestration, return an informative error response.
            error_choice = ChatCompletionResponseChoice(
                index=0,
                message={"role": "assistant", "content": f"Error in megaservice processing: {e}. Please ensure your microservices are running."},
                finish_reason="error" # Indicate an error occurred
            )
            return ChatCompletionResponse(
                id="error-" + str(int(time.time())),
                choices=[error_choice],
                created=int(time.time()),
                model=request.model if request.model else "default-megaservice-model",
                object="chat.completion"
            )


    def start(self):
        # Initialize the MicroService for your megaservice itself
        self.service = MicroService(
            self.__class__.__name__, # Name of the service (e.g., 'ExampleService')
            service_role=ServiceRoleType.MEGASERVICE, # Define its role
            host=self.host,
            port=self.port,
            endpoint=self.endpoint, # The API endpoint it listens on
            input_datatype=ChatCompletionRequest, # Expects ChatCompletionRequest as input
            output_datatype=ChatCompletionResponse, # Returns ChatCompletionResponse as output
        )

        # Add the route to handle incoming POST requests to your defined endpoint
        self.service.add_route(self.endpoint, self.handle_request, methods=["POST"])

        print(f"Starting OPEA Megaservice as a MicroService on {self.host}:{self.port}")
        self.service.start() # This call blocks and starts the FastAPI server


if __name__ == "__main__":
    # Instantiate and start your ExampleService
    example = ExampleService(host=MEGA_SERVICE_HOST_IP, port=MEGA_SERVICE_PORT)
    example.add_remote_service() # Configure the remote embedding and LLM services
    example.start() # Start the megaservice